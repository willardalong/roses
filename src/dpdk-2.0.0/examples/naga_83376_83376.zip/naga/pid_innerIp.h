#ifndef __PID_INNER_IP
#define __PID_INNER_IP




berr pid_innerip(struct pbuf *p,  hytag_t * hytag);


#endif
